from sqlalchemy import Column
from sqlalchemy import Integer
from sqlalchemy import String
from sqlalchemy import Float
from sqlalchemy import Boolean

from database.db import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)

    telegram_id = Column(
        Integer,
        unique=True,
        nullable=False
    )

    username = Column(String(100))

    first_name = Column(String(100))

    balance = Column(
        Float,
        default=0
    )

    referrals = Column(
        Integer,
        default=0
    )


class WithdrawRequest(Base):
    __tablename__ = "withdraw_requests"

    id = Column(Integer, primary_key=True)

    telegram_id = Column(
        Integer,
        nullable=False
    )

    amount = Column(
        Float,
        nullable=False
    )

    account_number = Column(
        String(100),
        nullable=False
    )

    status = Column(
        String(20),
        default="pending"
    )


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True)

    title = Column(
        String(255),
        nullable=False
    )

    link = Column(
        String(500),
        nullable=False
    )

    reward = Column(
        Float,
        default=1
    )

    active = Column(
        Boolean,
        default=True
    )


class CompletedTask(Base):
    __tablename__ = "completed_tasks"

    id = Column(Integer, primary_key=True)

    telegram_id = Column(
        Integer,
        nullable=False
    )

    task_id = Column(
        Integer,
        nullable=False
    )