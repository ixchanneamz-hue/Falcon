from database.db import Base
from database.db import engine

from database.models import User
from database.models import WithdrawRequest
from database.models import Task
from database.models import CompletedTask

Base.metadata.create_all(bind=engine)

print("Tables created successfully!")