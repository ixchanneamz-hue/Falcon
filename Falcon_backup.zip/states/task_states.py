from aiogram.fsm.state import State
from aiogram.fsm.state import StatesGroup


class CreateTaskState(StatesGroup):

    waiting_for_title = State()
    waiting_for_link = State()
    waiting_for_reward = State()


class DeleteTaskState(StatesGroup):

    waiting_for_task_id = State()