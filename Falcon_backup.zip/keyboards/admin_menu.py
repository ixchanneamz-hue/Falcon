from aiogram.types import ReplyKeyboardMarkup
from aiogram.types import KeyboardButton


def admin_menu():

    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="📊 الإحصائيات")],
            [KeyboardButton(text="💸 طلبات السحب")],
            [KeyboardButton(text="👥 المستخدمون")],
            [KeyboardButton(text="➕ إضافة مهمة")],
            [KeyboardButton(text="📋 عرض المهام")],
            [KeyboardButton(text="❌ حذف مهمة")],
            [KeyboardButton(text="🏠 رجوع")]
        ],
        resize_keyboard=True
    )