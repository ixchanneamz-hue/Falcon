from aiogram.types import InlineKeyboardMarkup
from aiogram.types import InlineKeyboardButton


def withdraw_admin_keyboard(request_id):

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ قبول",
                    callback_data=f"approve_{request_id}"
                ),
                InlineKeyboardButton(
                    text="❌ رفض",
                    callback_data=f"reject_{request_id}"
                )
            ]
        ]
    )