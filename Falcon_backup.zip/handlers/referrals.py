from aiogram import Router, F
from aiogram.types import Message

from database.db import SessionLocal
from database.models import User

router = Router()

BOT_USERNAME = "IxchanneBot"


@router.message(F.text == "👥 الإحالات")
async def referrals_handler(message: Message):

    db = SessionLocal()

    try:
        user = db.query(User).filter(
            User.telegram_id == message.from_user.id
        ).first()

        referral_link = (
            f"https://t.me/{BOT_USERNAME}?start={message.from_user.id}"
        )

        await message.answer(
            f"👥 نظام الإحالات\n\n"
            f"🔗 رابطك:\n{referral_link}\n\n"
            f"عدد المدعوين: {user.referrals}\n"
            f"رصيدك الحالي: {user.balance} درهم"
        )

    finally:
        db.close()