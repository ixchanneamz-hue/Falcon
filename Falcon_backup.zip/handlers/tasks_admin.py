from aiogram import Router
from aiogram import F

from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from database.db import SessionLocal
from database.models import Task

from states.task_states import (
    CreateTaskState,
    DeleteTaskState
)

router = Router()

ADMIN_ID = 986072050


@router.message(F.text == "➕ إضافة مهمة")
async def add_task_start(
    message: Message,
    state: FSMContext
):

    if message.from_user.id != ADMIN_ID:
        return

    await state.set_state(
        CreateTaskState.waiting_for_title
    )

    await message.answer(
        "📝 أدخل عنوان المهمة:"
    )


@router.message(
    CreateTaskState.waiting_for_title
)
async def task_title(
    message: Message,
    state: FSMContext
):

    await state.update_data(
        title=message.text
    )

    await state.set_state(
        CreateTaskState.waiting_for_link
    )

    await message.answer(
        "🔗 أدخل رابط المهمة:"
    )


@router.message(
    CreateTaskState.waiting_for_link
)
async def task_link(
    message: Message,
    state: FSMContext
):

    await state.update_data(
        link=message.text
    )

    await state.set_state(
        CreateTaskState.waiting_for_reward
    )

    await message.answer(
        "💰 أدخل قيمة المكافأة:"
    )


@router.message(
    CreateTaskState.waiting_for_reward
)
async def task_reward(
    message: Message,
    state: FSMContext
):

    try:
        reward = float(message.text)

    except ValueError:

        await message.answer(
            "❌ أدخل رقماً صحيحاً"
        )
        return

    data = await state.get_data()

    db = SessionLocal()

    try:

        task = Task(
            title=data["title"],
            link=data["link"],
            reward=reward
        )

        db.add(task)
        db.commit()

        await message.answer(
            "✅ تم إنشاء المهمة بنجاح"
        )

    finally:
        db.close()

    await state.clear()


@router.message(F.text == "📋 عرض المهام")
async def show_tasks(message: Message):

    if message.from_user.id != ADMIN_ID:
        return

    db = SessionLocal()

    try:

        tasks = db.query(Task).all()

        if not tasks:

            await message.answer(
                "📋 لا توجد مهام"
            )
            return

        text = "📋 قائمة المهام\n\n"

        for task in tasks:

            text += (
                f"🆔 {task.id}\n"
                f"📝 {task.title}\n"
                f"💰 {task.reward} درهم\n\n"
            )

        await message.answer(text)

    finally:
        db.close()


@router.message(F.text == "❌ حذف مهمة")
async def delete_task_start(
    message: Message,
    state: FSMContext
):

    if message.from_user.id != ADMIN_ID:
        return

    await state.set_state(
        DeleteTaskState.waiting_for_task_id
    )

    await message.answer(
        "🆔 أرسل رقم المهمة المراد حذفها:"
    )


@router.message(
    DeleteTaskState.waiting_for_task_id
)
async def delete_task(
    message: Message,
    state: FSMContext
):

    try:
        task_id = int(message.text)

    except ValueError:

        await message.answer(
            "❌ أدخل رقم مهمة صحيح"
        )
        return

    db = SessionLocal()

    try:

        task = db.query(Task).filter(
            Task.id == task_id
        ).first()

        if not task:

            await message.answer(
                "❌ المهمة غير موجودة"
            )

            await state.clear()
            return

        title = task.title

        db.delete(task)
        db.commit()

        await message.answer(
            f"✅ تم حذف المهمة:\n\n{title}"
        )

    finally:
        db.close()

    await state.clear()