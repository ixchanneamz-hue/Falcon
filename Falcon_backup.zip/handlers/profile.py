from aiogram import Router, F
from aiogram.types import Message

from database.db import SessionLocal
from database.models import User

router = Router()


@router.message(F.text == "💳 رصيدي")
async def my_balance(message: Message):

    db = SessionLocal()

    try:

        user = db.query(User).filter(
            User.telegram_id == message.from_user.id
        ).first()

        if not user:
            return

        await message.answer(
            f"💳 رصيدك الحالي:\n\n"
            f"💰 {user.balance} درهم"
        )

    finally:
        db.close()