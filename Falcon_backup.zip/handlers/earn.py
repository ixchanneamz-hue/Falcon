from aiogram import Router, F
from aiogram.types import Message

from keyboards.earn_menu import earn_menu
from keyboards.main_menu import main_menu

from database.db import SessionLocal
from database.models import Task
from database.models import User
from database.models import CompletedTask

router = Router()


@router.message(F.text == "💰 كسب المال")
async def earn_money(message: Message):

    await message.answer(
        "💰 مرحباً بك في قسم كسب المال\n\n"
        "اربح المال من المهام.",
        reply_markup=earn_menu()
    )


@router.message(F.text == "✅ إنجاز مهمة")
async def task_handler(message: Message):

    db = SessionLocal()

    try:

        tasks = db.query(Task).filter(
            Task.active == True
        ).all()

        if not tasks:

            await message.answer(
                "📋 لا توجد مهام متاحة حالياً."
            )
            return

        user_id = message.from_user.id

        for task in tasks:

            completed = db.query(
                CompletedTask
            ).filter(
                CompletedTask.telegram_id == user_id,
                CompletedTask.task_id == task.id
            ).first()

            if not completed:

                user = db.query(User).filter(
                    User.telegram_id == user_id
                ).first()

                if not user:
                    return

                user.balance += task.reward

                completed_task = CompletedTask(
                    telegram_id=user_id,
                    task_id=task.id
                )

                db.add(completed_task)

                db.commit()

                await message.answer(
                    f"📝 المهمة: {task.title}\n\n"
                    f"🔗 الرابط:\n{task.link}\n\n"
                    f"💰 المكافأة: {task.reward} درهم\n\n"
                    f"✅ تمت إضافة المكافأة إلى رصيدك."
                )

                return

        await message.answer(
            "✅ لقد أنجزت جميع المهام المتاحة."
        )

    finally:
        db.close()


@router.message(F.text == "📜 سجل مهامي المنجزة")
async def task_history(message: Message):

    db = SessionLocal()

    try:

        completed = db.query(
            CompletedTask
        ).filter(
            CompletedTask.telegram_id ==
            message.from_user.id
        ).all()

        if not completed:

            await message.answer(
                "📜 لا توجد مهام منجزة بعد."
            )
            return

        text = "📜 المهام المنجزة\n\n"

        for item in completed:

            task = db.query(Task).filter(
                Task.id == item.task_id
            ).first()

            if task:

                text += (
                    f"📝 {task.title}\n"
                    f"💰 {task.reward} درهم\n\n"
                )

        await message.answer(text)

    finally:
        db.close()


@router.message(F.text == "◀️ العودة للقائمة الرئيسية")
async def back_home(message: Message):

    await message.answer(
        "🏠 القائمة الرئيسية",
        reply_markup=main_menu()
    )