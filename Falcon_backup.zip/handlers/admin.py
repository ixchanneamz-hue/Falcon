from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from keyboards.admin_menu import admin_menu
from keyboards.main_menu import main_menu
from keyboards.withdraw_admin import withdraw_admin_keyboard

from database.db import SessionLocal
from database.models import User, WithdrawRequest

router = Router()

ADMIN_ID = 986072050


@router.message(F.text == "💪 لوحة الإدارة")
async def admin_panel(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    await message.answer(
        "💪 لوحة الإدارة",
        reply_markup=admin_menu()
    )


@router.message(F.text == "📊 الإحصائيات")
async def statistics(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    db = SessionLocal()

    try:
        users_count = db.query(User).count()

        pending_withdraws = (
            db.query(WithdrawRequest)
            .filter(WithdrawRequest.status == "pending")
            .count()
        )

        total_balance = sum(
            user.balance
            for user in db.query(User).all()
        )

        await message.answer(
            f"📊 الإحصائيات\n\n"
            f"👥 عدد المستخدمين: {users_count}\n"
            f"💸 طلبات السحب المعلقة: {pending_withdraws}\n"
            f"💰 إجمالي الأرصدة: {total_balance} درهم"
        )

    finally:
        db.close()


@router.message(F.text == "💸 طلبات السحب")
async def withdrawals(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    db = SessionLocal()

    try:
        requests = (
            db.query(WithdrawRequest)
            .filter(WithdrawRequest.status == "pending")
            .all()
        )

        if not requests:
            await message.answer(
                "لا توجد طلبات سحب معلقة."
            )
            return

        for req in requests:
            await message.answer(
                f"🆔 الطلب: {req.id}\n"
                f"👤 المستخدم: {req.telegram_id}\n"
                f"💰 المبلغ: {req.amount} درهم\n"
                f"🏦 الحساب: {req.account_number}\n"
                f"📌 الحالة: {req.status}",
                reply_markup=withdraw_admin_keyboard(req.id)
            )

    finally:
        db.close()


@router.callback_query(F.data.startswith("approve_"))
async def approve_withdraw(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        return

    request_id = int(callback.data.split("_")[1])

    db = SessionLocal()

    try:
        request = (
            db.query(WithdrawRequest)
            .filter(WithdrawRequest.id == request_id)
            .first()
        )

        if not request:
            await callback.answer(
                "الطلب غير موجود",
                show_alert=True
            )
            return

        request.status = "approved"

        user = (
            db.query(User)
            .filter(User.telegram_id == request.telegram_id)
            .first()
        )

        if user:
            user.balance -= request.amount

        db.commit()

        await callback.message.edit_text(
            f"✅ تم قبول الطلب #{request.id}"
        )

    finally:
        db.close()


@router.callback_query(F.data.startswith("reject_"))
async def reject_withdraw(callback: CallbackQuery):
    if callback.from_user.id != ADMIN_ID:
        return

    request_id = int(callback.data.split("_")[1])

    db = SessionLocal()

    try:
        request = (
            db.query(WithdrawRequest)
            .filter(WithdrawRequest.id == request_id)
            .first()
        )

        if not request:
            await callback.answer(
                "الطلب غير موجود",
                show_alert=True
            )
            return

        request.status = "rejected"

        db.commit()

        await callback.message.edit_text(
            f"❌ تم رفض الطلب #{request.id}"
        )

    finally:
        db.close()


@router.message(F.text == "👥 المستخدمون")
async def users_list(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    db = SessionLocal()

    try:
        users = db.query(User).all()

        if not users:
            await message.answer(
                "لا يوجد مستخدمون."
            )
            return

        text = "👥 قائمة المستخدمين\n\n"

        for user in users:
            text += (
                f"🆔 {user.telegram_id}\n"
                f"👤 {user.first_name}\n"
                f"💰 الرصيد: {user.balance} درهم\n"
                f"👥 الإحالات: {user.referrals}\n\n"
            )

        await message.answer(text)

    finally:
        db.close()


@router.message(F.text == "🏠 رجوع")
async def back_home(message: Message):
    if message.from_user.id != ADMIN_ID:
        return

    await message.answer(
        "🏠 القائمة الرئيسية",
        reply_markup=main_menu(True)
    )