from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message

from keyboards.main_menu import main_menu
from database.user_service import get_or_create_user

ADMIN_ID = 986072050

router = Router()


@router.message(CommandStart())
async def start_handler(message: Message):

    get_or_create_user(message.from_user)

    is_admin = (
        message.from_user.id == ADMIN_ID
    )

    await message.answer(
        "مرحباً بك في Falcon Bot 💰",
        reply_markup=main_menu(is_admin)
    )