from aiogram import Router, F
from aiogram.types import Message

from database.db import SessionLocal
from database.models import User, WithdrawRequest

router = Router()


@router.message(F.text == "💸 سحب الأرباح")
async def withdraw_menu(message: Message):

    db = SessionLocal()

    try:
        user = db.query(User).filter(
            User.telegram_id == message.from_user.id
        ).first()

        await message.answer(
            f"💸 طلب سحب الأرباح\n\n"
            f"رصيدك الحالي: {user.balance} درهم\n"
            f"الحد الأدنى للسحب: 100 درهم\n\n"
            f"أرسل الطلب بهذا الشكل:\n"
            f"2304501234567890 150"
        )

    finally:
        db.close()


@router.message(F.text.regexp(r"^\d+\s+\d+$"))
async def withdraw_request(message: Message):

    text = message.text.strip()

    account_number, amount = text.split()

    amount = float(amount)

    db = SessionLocal()

    try:

        user = db.query(User).filter(
            User.telegram_id == message.from_user.id
        ).first()

        if not user:
            return

        if amount < 100:
            await message.answer(
                "❌ الحد الأدنى للسحب هو 100 درهم"
            )
            return

        if user.balance < amount:
            await message.answer(
                "❌ رصيدك غير كافٍ"
            )
            return

        request = WithdrawRequest(
            telegram_id=message.from_user.id,
            amount=amount,
            account_number=account_number
        )

        db.add(request)
        db.commit()

        await message.answer(
            f"✅ تم إنشاء طلب السحب\n\n"
            f"المبلغ: {amount} درهم\n"
            f"الحالة: قيد المراجعة"
        )

    finally:
        db.close()