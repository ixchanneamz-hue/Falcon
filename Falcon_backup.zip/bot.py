import asyncio

from aiogram import Bot
from aiogram import Dispatcher

from handlers.start import router as start_router
from handlers.earn import router as earn_router
from handlers.referrals import router as referrals_router
from handlers.withdraw import router as withdraw_router
from handlers.admin import router as admin_router
from handlers.tasks_admin import router as tasks_admin_router
from handlers.profile import router as profile_router

TOKEN = "8550244813:AAHzUmnyjQ54nKEpi4ceU09ISRboVlBL01Y"


async def main():

    bot = Bot(token=TOKEN)

    dp = Dispatcher()

    dp.include_router(start_router)
    dp.include_router(earn_router)
    dp.include_router(referrals_router)
    dp.include_router(withdraw_router)
    dp.include_router(admin_router)
    dp.include_router(tasks_admin_router)
    dp.include_router(profile_router)

    print("Falcon Bot Started ✅")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())